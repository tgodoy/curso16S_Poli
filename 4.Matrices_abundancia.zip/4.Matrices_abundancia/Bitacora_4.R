##############################################################################
#########         Analisis de amplicones del gen rRNA 16S            #########
#########    E. Ernestina Godoy Lozano (elizabeth.godoy@insp.mx)     #########
#########                    Bitacora de comandos                    #########
#########             Exploracion de matrices de abundancia          #########
##############################################################################

# Texto sin acentos

# Cargar librerias de trabajo

library(gplots)
library(ggplot2)
library(vegan)
library(reshape2)
library(metagenomeSeq)

# Posicionarme en mi espacio de trabajo
getwd()

# Cargar datos
tabla <- read.delim("tablas/integrated_matrix.txt", header=TRUE, row.names=1)
head(tabla)
dim(tabla)

############# Matrices de abundancia
### Ejercicio 1. Niveles taxonomicos

# Añadir los nombres de los taxa a un objeto
asignacion_taxonomica <- data.frame(completo=rownames(tabla))

asignacion_taxonomica$Domain <- sapply(as.character(asignacion_taxonomica$completo), function(x){strsplit(x, ";")[[1]][1]})
asignacion_taxonomica$Phylum <- sapply(as.character(asignacion_taxonomica$completo), function(x){strsplit(x, ";")[[1]][2]})
asignacion_taxonomica$Class <- sapply(as.character(asignacion_taxonomica$completo), function(x){strsplit(x, ";")[[1]][3]})
asignacion_taxonomica$Order <- sapply(as.character(asignacion_taxonomica$completo), function(x){strsplit(x, ";")[[1]][4]})
asignacion_taxonomica$Family <- sapply(as.character(asignacion_taxonomica$completo), function(x){strsplit(x, ";")[[1]][5]})
asignacion_taxonomica$Genus <- sapply(as.character(asignacion_taxonomica$completo), function(x){strsplit(x, ";")[[1]][6]})
asignacion_taxonomica$Species <- sapply(as.character(asignacion_taxonomica$completo), function(x){strsplit(x, ";")[[1]][7]})

head(asignacion_taxonomica)
View(asignacion_taxonomica)

# Comprimir matriz a los distintos niveles taxonomicos
asig_unicas <- unique(asignacion_taxonomica$Phylum)
taxa_level <- matrix(data=0, nrow=length(asig_unicas) , ncol=dim(tabla)[2])

colnames(taxa_level) <- colnames(tabla)
rownames(taxa_level) <- asig_unicas
dim(taxa_level)

for (i in 1:dim(taxa_level)[1]){
	bicho <- rownames(taxa_level)[i]
	nums <- which(asignacion_taxonomica$Phylum== bicho)
	for (j in 1:dim(taxa_level)[2]){
		taxa_level[i,j] <- sum(tabla[nums,j])
	}
}

head(taxa_level)
View(taxa_level)

# Generaremos un ciclo for para obtener todos los niveles taxonomicos desde una sola instruccion
taxonomics_levels <- c("Domain", "Phylum", "Class", "Order", "Family", "Genus", "Species")
for (k in 1:length(taxonomics_levels)){
	nivel <- taxonomics_levels[k]
	asig_unicas <- unique(asignacion_taxonomica[,which(colnames(asignacion_taxonomica)== taxonomics_levels[k])])
	taxa_level <- matrix(data=0, nrow=length(asig_unicas) , ncol=dim(tabla)[2])
	colnames(taxa_level) <- colnames(tabla)
	rownames(taxa_level) <- asig_unicas
	for (i in 1:dim(taxa_level)[1]){
		bicho <- rownames(taxa_level)[i]
		nums <- which(asignacion_taxonomica[,which(colnames(asignacion_taxonomica)== taxonomics_levels[k])]== bicho)
		for (j in 1:dim(taxa_level)[2]){
			taxa_level[i,j] <- sum(tabla[nums,j])
		}
	}
	num_no_asignaciones <- which(rowSums(taxa_level)==0)
	if (length(num_no_asignaciones)>0){
		taxa_level <- taxa_level[-num_no_asignaciones,]
	}
	print(paste("El nivel taxonomico ", nivel, " contiene ", dim(taxa_level)[1], " asignaciones", sep=""))
	exportMat(taxa_level, file =paste("tablas/taxa_levels/",nivel, ".txt", sep=""))
}

dir("tablas/taxa_levels")


### Ejercicio 2. Matrices de abundancia relativa

View(tabla)

# Convertir una matriz de abundancia absoluta a relativa
totales <- colSums(tabla)
tabla_rel <- matrix(nrow=dim(tabla)[1], ncol=dim(tabla)[2])
colnames(tabla_rel) <- colnames(tabla)
rownames(tabla_rel) <- rownames(tabla)

for (i in 1:dim(tabla)[1]){
	for (j in 1:dim(tabla)[2]){
		tabla_rel[i,j] <- (tabla[i,j]/totales[j])*100
	}
}

View(tabla_rel)
colSums(tabla_rel)

exportMat(tabla_rel, file ="tablas/percent_integrated_matrix.txt")


# crear una funcion
abund_relativa <- function(input, output){
	tabla <- read.delim(input, header=TRUE, row.names=1)
	totales <- colSums(tabla)
	tabla_rel <- matrix(nrow=dim(tabla)[1], ncol=dim(tabla)[2])
	colnames(tabla_rel) <- colnames(tabla)
	rownames(tabla_rel) <- rownames(tabla)

	for (i in 1:dim(tabla)[1]){
		for (j in 1:dim(tabla)[2]){
			tabla_rel[i,j] <- (tabla[i,j]/totales[j])*100
		}
	}
	exportMat(tabla_rel, file = output)
}


# ejemplo de como correr la funcion abund_relativa()
abund_relativa("tablas/taxa_levels/Genus.txt", "tablas/percent_Genus.txt")
abund_relativa("tablas/taxa_levels/Class.txt", "tablas/percent_Class.txt")

dir("tablas")

### Ejercicio 3. Generacion de barras apiladas
# Cargar matriz a nivel de clase en abundancias relativas
tabla <- read.delim("tablas/percent_Class.txt", header=T, row.names=1)
dim(tabla)

# Contraer la informacion de la matrix en dos columnas (Fusionar la matriz)
melt_subtable <- melt(tabla)

# Añadir los nombres de los taxa en una columna extra
melt_subtable$Taxa <-  as.character(rep(rownames(tabla), dim(tabla)[2]))

# Ordene los nombres de los taxa de acuerdo a un orden alfabetico
melt_subtable$Taxa <- factor(melt_subtable$Taxa, levels=sort(rownames(tabla)))

# Generar un vector de colores al azar
color = grDevices::colors()[grep('gr(a|e)y', grDevices::colors(), invert = T)]
my_color=c(sample(color, dim(tabla)[1]-1, replace=FALSE), "gray")

# Generar grafica de barras apiladas
ggplot(melt_subtable, aes(x=variable, y=value, fill=Taxa)) + 
  geom_bar(stat="identity") +  
	scale_fill_manual(values=my_color, limits=rownames(tabla)) + 
	theme(axis.text.x = element_text(angle=30, hjust=1, vjust=1, size=8), 
	      panel.background= element_rect(fill = NA, colour = "black"), 
	      panel.grid.major = element_line(colour = "grey90"), 
	      legend.key = element_rect(fill = "white"), 
	      legend.text=element_text(size=8), 
	      legend.position="bottom") + 
	labs(x = "", y = "Relative abundance (%)", fill="") + 
  scale_y_continuous(breaks=c(0, 20, 40, 60, 80, 100))
ggsave("figuras/sock_plots_Class.png", device = "png", dpi = 300, 
       units = "px", bg = "white")


### Ejercicio 4. Cortes de abundancia en la matriz
View(tabla)
dim(tabla)

# Cargar matriz a nivel de clase en abundancias relativas
#tabla <- read.delim("tablas/percent_Class.txt", header=T, row.names=1)
View(tabla)
dim(tabla)

# Determinar la media de abundancia relativa para cada Taxa (fila)
maxab <- apply(tabla, 1, mean)
length(maxab)
head(maxab)

## Determinar un corte de abundancia, aqui marcamos un corte del 1%
# 1%
cut <- 1

#### Realizar el punto de corte a la matriz
# Obtener los taxa que tienen una abundancia mayor al corte que estamos determinando
n1 <- maxab[which(maxab > cut)]

# Numero de taxas con los que nos quedaremos
length(n1)

# Generar matriz con el corte 
subtable <- tabla[which(rownames(tabla) %in% names(n1)),]
dim(subtable)

# Ordenar la matrix de acuerdo a la media o al maximo de abundancia relativa
tabla_n1 <- data.frame(n1)
tabla_n1$taxa <- names(n1)
df_ordenado <- tabla_n1[order(tabla_n1$n1, decreasing =T ),]
orden <- df_ordenado$taxa

# Generar una nueva matriz, ya ordenada
new <- matrix(nrow=dim(subtable)[1], ncol=dim(subtable)[2])
colnames(new) <- colnames(subtable)
rownames(new) <- orden

#fill new matrix
for (i in 1:dim(new)[2]){
  numCol <- which(colnames(tabla)==colnames(new)[i])
  for (j in 1:dim(new)[1]){
    numRow <- which(rownames(tabla)==rownames(new)[j])
    new[j,i] <- tabla[numRow, numCol]
  }
}

View(new)

# Agregar una fila con los valores de la abundancia relativa menor al corte que generamos
totales <- colSums(new)

subtable2 <- as.data.frame(matrix(ncol=dim(new)[2], nrow=1))
colnames(subtable2) <- colnames(new)
rownames(subtable2) <- paste("Abundance <", cut, "%", sep="")
for (i in 1:dim(subtable2)[2]){
  subtable2[1,i] <- 100-totales[i]
}
new <- rbind(new, subtable2)

# Escribir nueva matriz de abundancia ##### Hacer enfasis en que guarden esta matrix
exportMat(as.matrix(new), file ="tablas/percent_Class_more_1_perc.txt")

# Contraer la informacion de la matrix en dos columnas (Fusionar la matriz)
melt_subtable <- melt(new)

# Añadir los nombres de los taxa en una columna extra
melt_subtable$Taxa <-  as.character(rep(rownames(new), dim(new)[2]))

# Ordene los nombres de los taxa de acuerdo a un orden alfabetico
melt_subtable$Taxa <- factor(melt_subtable$Taxa, levels=rownames(new))
head(melt_subtable)

# Generar un vector de colores al azar
# Quitar la escala de grises del vector de colores
color = grDevices::colors()[grep('gr(a|e)y', grDevices::colors(), invert = T)]

# Generar un vector de colores al azar con un color gris para los taxa menos abundantes
my_color=c(sample(color, dim(new)[1]-1, replace=FALSE), "gray")

# Generar mi grafica de barras apiladas con el corte de abundancia
ggplot(melt_subtable, aes(x= Var2, y=value, fill=Taxa)) + geom_bar(stat="identity") +  
  scale_fill_manual(values=my_color, limits=rownames(new)) + 
  theme(axis.text.x = element_text(angle=30, hjust=1, vjust=1, size=6), panel.background= element_rect(fill = NA, colour = "black"), panel.grid.major = element_line(colour = "grey90"), legend.key = element_rect(fill = "white"), legend.text=element_text(size=6), legend.position="bottom") + 
  labs(x = "", y = "Relative abundance (%)", fill="") + 
  scale_y_continuous(breaks=c(0, 20, 40, 60, 80, 100))
ggsave("figuras/sock_plots_Class_more_1_perc.png", device = "png", dpi = 300, units = "px", bg = "white")


##### Listado de objetos
ls()

#### Informacion de la sesion
sessionInfo()

