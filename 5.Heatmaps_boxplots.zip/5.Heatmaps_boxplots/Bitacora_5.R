##############################################################################
#########         Analisis de amplicones del gen rRNA 16S            #########
#########    E. Ernestina Godoy Lozano (elizabeth.godoy@insp.mx)     #########
#########                    Bitacora de comandos                    #########
#########                      Heatmaps y boxplot                    #########
##############################################################################

# Texto sin acentos

# Posicionarme en mi espacio de trabajo
getwd()
dir()

### Cargar las librerias de trabajo
suppressMessages(library(gplots))
library(ggplot2)
library(vegan)
library(reshape2)
library(metagenomeSeq)
library(Heatplus)
library(RColorBrewer)

#### leer los datos

tabla <- t(read.delim("tablas/percent_Class_more_1_perc.txt", 
                      header=T, row.names=1))
dim(tabla)
View(tabla)

### Ejercicio 1. heatmap basico

colors <- colorRampPalette(c("lightyellow", "dodgerblue"), space="rgb")(100)
length(colors)
head(colors)

heatmap(tabla, Rowv=NA, Colv= NA, col= colors, margins= c(10,2))

### Ejercicio 2. agrupaciones jerarquicas

mat_dist <- vegdist(tabla, method="bray")

row.clus <- hclust(mat_dist, "aver")
heatmap(tabla, Rowv=as.dendrogram(row.clus), 
        Colv= NA, col= colors, margins= c(10,3))

mat_dist_class <-vegdist(t(tabla), method = "bray") 
col.clus <- hclust(mat_dist_class, "aver")

png("figuras/heatmap_class_basico.png", width = 300*10, height = 300*6, units = "px", res=300)
heatmap(tabla, Rowv=as.dendrogram(row.clus), 
        Colv= as.dendrogram(col.clus), col= colors, margins= c(12,3))
dev.off()

##### Ejercicio 3. Identificar cluster

View(tabla)
muestras <- data.frame(nombre=rownames(tabla))
head(muestras)
muestras
muestras$clase <- sapply(as.character(muestras$nombre), function(x){strsplit(x, "_")[[1]][1]})

muestras$color <- "coral1"
muestras$color[which(muestras$clase=="Someras")] <- "seagreen2"
muestras$color[which(muestras$clase=="Profundas")] <- "deepskyblue"

heatmap.2(tabla, Rowv = as.dendrogram(row.clus), 
          Colv=as.dendrogram(col.clus),
          col=colors, 
          RowSideColors=muestras$color, margins=c(6,3))

dev.off()


png("figuras/heatmap_class_complejo.png", width = 300*10, height = 300*6, units = "px", res=300)
heatmap.2(tabla, Rowv = as.dendrogram(row.clus), 
          Colv=as.dendrogram(col.clus),
          col=colors, 
          RowSideColors=muestras$color, 
          margins=c(13,10),
          trace="none", density.info = "none", 
          xlab="Clase", ylab="Muestras",
          main="Heatmap a nivel de Clase", lhei = c(2,8))
legend("bottomleft", c("Costa", "Profundas", "Someras"), 
       fill=c("coral1", "deepskyblue", "seagreen2"))
dev.off()

#### Ejercicio 4. Agregar anotaciones de otras variables

variables <- read.delim("tablas/abiotic_variables.txt", header=T, row.names=1)
head(variables)

var_interes <- c("Naphthalene", "Fluorene", "Organic_Matter")
subtabla <- variables[,which(colnames(variables)%in% var_interes)]
head(subtabla)

head(muestras)
muestras$estacion <- sapply(as.character(muestras$nombre), function(x){strsplit(x, "_")[[1]][2]})
muestras$clase2 <- sapply(as.character(muestras$nombre), function(x){strsplit(x, "")[[1]][1]})
muestras$clase3 <- paste(muestras$clase2, muestras$estacion, sep=".")
muestras

head(tabla)
rownames(tabla) <- muestras$clase3

colors <- colorRampPalette(c("lightyellow", "dodgerblue"), space="rgb")(40)

plot(annHeatmap2(tabla, col=colors, breaks = 50, 
                 dendrogram = list(Row = list(dendro = as.dendrogram(row.clus)), Col = list(dendro = as.dendrogram(col.clus))),
                 legend=3, labels=list(Col=list(nrow=12)),
                 ann=list(Row=list(data=subtabla)),
                 cluster = list(Row=list(cuth=0.25, col=c("seagreen2", "deepskyblue", "coral1")))))
dev.off()


png("figuras/heatmap_class_variables.png", width = 300*10, height = 300*6, units = "px", res=300)
plot(annHeatmap2(tabla, col = colors, breaks = 50,
                 dendrogram = list(Row = list(dendro = as.dendrogram(row.clus)), 
                                   Col = list(dendro = as.dendrogram(col.clus))),
                 legend = 3, labels = list(Col = list(nrow = 12)), 
                 ann = list(Row = list(data = subtabla)),
                 cluster = list(Row = list(cuth = 0.25, col = c("seagreen2", "deepskyblue", "coral1")))))
dev.off()

#########################################################
###                Library qiime2R                    ###
###   Ejercicio: Leyendo y manejando artifacs en R    ###
#########################################################

# Cargar librerias de trabajo
library(qiime2R)
library(tidyverse)

# Leer el "artifac" que genero QIIME2 (table.qza)
tabla_qza <- read_qza("qiime2/table.qza")

# Visualizar la estructura de nuestro objeto
str(tabla_qza)
class(tabla_qza)

# Extraer la informacion del objeto tabla_qza como una lista
names(tabla_qza)

# Acceder a la informacion de las features (ASVs)
View(tabla_qza$data)
head(tabla_qza$data)

# Asociar la taxonomia
taxonomia_qza <- read_qza("qiime2/taxonomy_blast.qza")
str(taxonomia_qza)
class(taxonomia_qza)

# Acceder a la taxonomia
View(taxonomia_qza$data)

# Dividir en niveles taxonomicos la taxonomia usando parse_taxonomy()
taxa_sep <- parse_taxonomy(taxonomia_qza$data)
View(taxa_sep)

# Comprimir data.frame a un nivel taxonomico en particular (Clase)
class_table <- summarize_taxa(tabla_qza$data, taxa_sep)$Class

View(class_table)

# Grafica de barras apilada y heatmaps usando la informacion de metadata
# Cargar el archivo de metadata.tsv
metadata <- read_q2metadata("qiime2/metadata.tsv")
View(metadata)

taxa_barplot(class_table, metadata,"Zone")
taxa_heatmap(class_table, metadata,"Type")

# Cambiar gamma de colores de acuerdo a la gramatica de ggplot2
taxa_barplot(class_table, metadata,"Zone") +
  scale_fill_manual(values=my_color) +
  theme(text = element_text(size=10), legend.position="bottom") +
  scale_y_continuous(breaks=c(0, 20, 40, 60, 80, 100)) +
  labs(fill="")

taxa_heatmap(class_table, metadata,"Type") + 
  scale_fill_gradientn(colours = terrain.colors(10))

taxa_heatmap(class_table, metadata,"Type") +
  scale_fill_gradient(low = "gold", high = "green3", na.value = NA)

# Guardar imagen en png
png("figuras/taxa_heatmap.png", width = 10*300, height = 8*300, res = 300, pointsize = 8)
taxa_heatmap(class_table, metadata,"Type")
dev.off()


####################
####  BOXPLOTS  ####
####################

getwd()
setwd("~/PASPE_2023_Datos_genomicos_R/4.Metagenomica_heatmaps_boxplots")

suppressMessages(library(gplots))
suppressMessages(library(ggplot2))
suppressMessages(library(vegan))
suppressMessages(library(reshape2))
suppressMessages(library(metagenomeSeq))
suppressMessages(library(Heatplus))
suppressMessages(library(RColorBrewer))
sessionInfo()

tabla <- t(read.delim("tablas/percent_Class_more_1_perc.txt", 
                      header=T, row.names = 1))
View(tabla)
dim(tabla)

taxas <- c("Acidimicrobiia", "Betaproteobacteria", 
           "Clostridia", "Planctomycetia")

new_tabla <- tabla[,which(colnames(tabla)%in% taxas)]
head(new_tabla)

dim(new_tabla)

melt_tabla <- melt(new_tabla)
head(melt_tabla)

# Cambiar los nombres de las columnas
colnames(melt_tabla) <- c("Muestra", "Taxa","value")
head(melt_tabla)

melt_tabla$clase <- sapply(as.character(melt_tabla$Muestra), 
                           function(x){strsplit(x, "_")[[1]][1]}) 

ggplot(data=melt_tabla, aes(x=Taxa, y=value, fill=clase)) +
        geom_boxplot()

ggplot(data=melt_tabla, aes(x=Taxa, y=value, fill=clase)) +
        geom_boxplot() +
        scale_fill_manual(values=c("coral1", "deepskyblue", "seagreen2"))+
        labs(title= "Boxplots at Class level", y= "Relative frequency (%)", x="", fill="Samples") +
        theme_bw()


ggplot(data=melt_tabla, aes(x=Taxa, y=value, fill=clase)) +
        geom_boxplot() +
        scale_fill_manual(values=c("coral1", "deepskyblue", "seagreen2"))+
        labs(title= "Boxplots at Class level", y= "Relative frequency (%)", x="", fill="Samples") +
        theme_bw()
ggsave("figuras/boxplot_class.png", device = "png", dpi = 300)

###### ggpurb
# Cargar librerias de trabajo
library(ggpubr)

ggboxplot(melt_tabla, x= "Taxa", y = "value", 
          color = "clase", fill = "clase",
          palette = c("#FF5733", "#2782DE", "#FFC300"))

## Añadir barras de error y muescas
ggboxplot(melt_tabla, x= "Taxa", y = "value", 
          color = "clase", fill = "clase",
          palette = c("#FF5733", "#2782DE", "#FFC300"),
          bxp.errorbar = TRUE, 
          notch = TRUE)

# Cambiar las etiquetas de los ejes y añadir los puntos
ggboxplot(melt_tabla, x= "Taxa", y = "value", 
          color = "clase",
          palette = c("#FF5733", "#2782DE", "#FFC300"),
          bxp.errorbar = TRUE, 
          notch = FALSE, 
          xlab = "", 
          ylab= "Relative frequency (%)", 
          add = "jitter")
ggsave("figuras/ggboxplot_class.png", device = "png", dpi = 300)

# Añadir comparaciones estadisticas
# Determinar el tipo de datos con el que voy a realizar las comparaciones
# Aplicamos una prueba de normalidad y nos enfocaremos solo a un Taxa

shapiro.test(melt_tabla$value[which(melt_tabla$Taxa=="Clostridia")])

# Si el resultado de p < 0.05 los datos son No parametricos
##  2 distribuciones ---> wilcoxon.test
##  +2 distribuciones --->  Kruskal-Wallis
# Si el resultado de p > 0.05 los datos son Parametricos
##  2 distribuciones ---> t.test
##  +2 distribuciones --->  anova

# generar una lista con las comparaciones
mis_comparaciones <-  list(c("Costa", "Profundas"), 
                           c("Costa", "Someras"),  
                           c("Profundas", "Someras"))

# Acomodaremos de manera diferentes los datos 
ggboxplot(melt_tabla[which(melt_tabla$Taxa=="Clostridia"),], 
          x= "clase", y = "value", 
          color = "clase",
          palette = c("#FF5733", "#2782DE", "#FFC300"),
          bxp.errorbar = TRUE, 
          notch = FALSE, 
          xlab = "", 
          ylab= "Relative frequency (%)", 
          title = "Clostridia",
          add = "jitter") +
  rremove("legend") +
  stat_compare_means(comparisons = mis_comparaciones, 
                     label = "p.signif",
                     method = "wilcox.test")  +
  stat_compare_means(label.y = 16, method = "kruskal.test")
ggsave("figuras/ggboxplot_class_Clostridia.png", device = "png", dpi = 300)

#### Graficos para publicacion

A <- ggboxplot(melt_tabla[which(melt_tabla$Taxa=="Clostridia"),], 
          x= "clase", y = "value", 
          color = "clase",
          palette = c("#FF5733", "#2782DE", "#FFC300"),
          bxp.errorbar = TRUE, 
          notch = FALSE, 
          xlab = "", 
          ylab= "Relative frequency (%)", 
          title = "Clostridia",
          add = "jitter") +
  rremove("legend") +
  stat_compare_means(comparisons = mis_comparaciones, 
                     label = "p.signif",
                     method = "wilcox.test")  +
  stat_compare_means(label.y = 16, method = "kruskal.test")

B <- ggboxplot(melt_tabla[which(melt_tabla$Taxa=="Planctomycetia"),], 
          x= "clase", y = "value", 
          color = "clase",
          palette = c("#FF5733", "#2782DE", "#FFC300"),
          bxp.errorbar = TRUE, 
          notch = FALSE, 
          xlab = "", 
          ylab= "Relative frequency (%)", 
          title = "Planctomycetia",
          add = "jitter") +
  rremove("legend") +
  stat_compare_means(comparisons = mis_comparaciones, 
                     label = "p.signif",
                     method = "wilcox.test")  +
  stat_compare_means(label.y = 16, method = "kruskal.test")

C <- ggboxplot(melt_tabla[which(melt_tabla$Taxa=="Betaproteobacteria"),], 
               x= "clase", y = "value", 
               color = "clase",
               palette = c("#FF5733", "#2782DE", "#FFC300"),
               bxp.errorbar = TRUE, 
               notch = FALSE, 
               xlab = "", 
               ylab= "Relative frequency (%)", 
               title = "Betaproteobacteria",
               add = "jitter") +
  rremove("legend") +
  stat_compare_means(comparisons = mis_comparaciones, 
                     label = "p.signif",
                     method = "wilcox.test")  +
  stat_compare_means(label.y = 16, method = "kruskal.test")

# Generar mi arreglo de imagenes
ggarrange(A, B, C, ncol = 2, nrow = 2, labels = c("A", "B", "C"))

# Ordenarlas mejor
BC <- ggarrange(B, C, ncol = 2, nrow = 1, labels = c("B", "C"))
ggarrange(A, BC, ncol = 1, nrow = 2, labels = c("A"))

ggsave("figuras/Fig1ABC.png", device= "png", height = 8, width = 12)
